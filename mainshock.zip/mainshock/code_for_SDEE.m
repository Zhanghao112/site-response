function main
% This script is a demonstration of how to get the site response evolution
% from the seismograms recorded by the 6 selected stations during the 2011 
% Mw 9.0 Tohoku earthquake.
% It can also be used for other nonstationary seismic signal analysis.
% It may cost about 1 minutes to obtain the final result.
% Author: Hao Zhang, HUST, Wuhan China
% Date Created: 31 March 2020
% E-mail: 674238265@qq.com
%--------------------------------------------------------------------------
% Input parameters:
%   station name
%   LB: low boundary of the filter 
%   HB: high boundary of the filter 
%   step: movement step of the moving time window 
%   band_width: width of the moving time window 
%   SBW: width of the smoothing window
%   s0: interpolation parameter
%   fc: interpolation cut frequency
%--------------------------------------------------------------------------
% Abbreviation:
%   re: result
%   temp: temporary
%   Ref: reference
%   tf: transfer function
%   STFT: short time Fourier transform
%--------------------------------------------------------------------------
kikname={'FKSH09';'FKSH10';'IBRH11';'IBRH12';'IBRH15';'TCGH12'};
global LB HB band_width step SBW s0 fc
LB=0.1; HB=20; step=1; band_width=10.24;SBW=1.5;s0=3000;fc=30;
for i=1:size(kikname,1)
    tic    
    [rs,rb,f]=text_read(['mainshock\',kikname{i,1},'1103111446']);   
    [u,F,tf]=SBR_STFT(rs,rb,f); 
    [pf,amp]=detect_pf(F,tf);
   
    figure (1)
    subplot (2,3,i)
    plot (u,F(pf),'--','color',[0.7,0.7,0.7])
    hold on
    plot (u,mean(F(pf),2),'-r')
    hold on
    xlim([0,300])
    title(kikname{i,1})
    
    figure (2)
    subplot (2,3,i)
    plot (u,amp,'--','color',[0.7,0.7,0.7])
    hold on
    plot (u,mean(amp,2),'-r')
    xlim([0,300])
    title(kikname{i,1})
    toc
end
end
%--------------------------------------------------------------------------
function [rs,rb,f]=text_read(path)
% Returns the seismograms in 18 directions and the samlping frequency.
% rs: seismic data recorded in the surface.
% rb: seismic data recorded in the borehole.
% f: sampling ferquency.
ew1=textread([path,'.EW1'],'%f','headerlines',17);
ew2=textread([path,'.EW2'],'%f','headerlines',17);
ns1=textread([path,'.NS1'],'%f','headerlines',17);
ns2=textread([path,'.NS2'],'%f','headerlines',17);
f=textread([path,'.EW1'],'%*s%*s%n',1,'headerlines',10);
[kb1,kb2]=textread([path,'.EW1'],'%*s%*s%n%*6s%n',1,'headerlines',13);
[ks1,ks2]=textread([path,'.EW2'],'%*s%*s%n%*6s%n',1,'headerlines',13);
kb=kb1/kb2;
ks=ks1/ks2;
rbew=(ew1-mean(ew1))*kb;
rsew=(ew2-mean(ew2))*ks;
rbns=(ns1-mean(ns1))*kb;
rsns=(ns2-mean(ns2))*ks;
th=(0:17)/18*pi;
rs=rsew*cos(th)+rsns*sin(th);
rb=rbew*cos(th)+rbns*sin(th);
end
%--------------------------------------------------------------------------
function [u,F2,tf]=SBR_STFT(rs,rb,f)
% Returns spectral ratios in 18 directions using SBR based on STFT.
% u: central time of the time window.
% F2: frequency after interpolation.
% tf: obtained spectral ratios (transfer function in frequency domain).
global LB HB band_width step SBW s0 fc
for j=1:size(rs,2)
    [u,F,re_s]=ST(rs(:,j),f,band_width,step);
    [u,F,re_b]=ST(rb(:,j),f,band_width,step);
    [b,a]=butter(4,[LB,HB]/(f/2));
    re_s=filter(b,a,re_s);
    s=2^nextpow2(size(re_s,1));
    rs_fft=abs(fft(re_s,s));
    rb_fft=abs(fft(re_b,s));
    w=parzenwin(ceil(s/100*SBW))/sum(parzenwin(ceil(s/100*SBW)));
    rs_fft=imfilter(rs_fft,w,'symmetric','same');
    rb_fft=imfilter(rb_fft,w,'symmetric','same');
    tf_j=rs_fft./rb_fft;
    F=(0:f/s:f-f/s)';
    I=F<fc;
    F2=(0:fc/s0:fc-fc/s0)';
    tf(:,:,j)=interp1(F(I),tf_j(I,:),F2,'linear','extrap');
end
end
function [u,F,re_s]=ST(rs,f,tband,step)
% Returns the seismic data based on the original seismogram and moving time
% window parameters.
% u: central time of the time window
% F: frequency for the seismic data in frequency domin.
% re_s: result of the seismic data package
b=fix(tband*f);
n=step*f;
m=fix(length(rs)/(step*f));
for i=1:m-fix(b/n)-1
   temp=rs((i-1)*n+1:(i-1)*n+b);
   temp=temp-mean(temp);
   re_s(:,i)=temp.*tukeywin(b,0.05);
   u(i)=step*(i-1)+tband/2;   
end
F=(0:f/2^nextpow2(b):f-f/2^nextpow2(b))';
end
%--------------------------------------------------------------------------
function [pf,amp]=detect_pf(F,tf)
% Returns the predominant frequency and corresponding amplification factor.
ref_pf_evolution=detect_reference_t(F,tf);
for i=1:size(tf,3)
    for j=1:size(tf,2)
        [temp_amp,temp_pf]=findpeaks(tf(:,j,i));
        [~,flag]=min(abs(temp_pf-ref_pf_evolution(j,1)));
        pf(j,i)=temp_pf(flag);
        amp(j,i)=temp_amp(flag);
    end
end
end
function Ref_pf_evolution=detect_reference_t(F,tf)
% Returns a preliminary predominant frequency evoluiton as reference.
%--------------------------------------------------------------------------
% Average and smooth the tf to enhance its stability.
% Choose the coda part of the tf as the reference for cross correlation.
% Delete the sigular value, smooth the result and redifine the noise part.
iostropic_tf=mean(tf,3);
w=(parzenwin(300)/sum(parzenwin(300)))*(parzenwin(10)/sum(parzenwin(10)))';
iostropic_tf=imfilter(iostropic_tf,w,'symmetric','same');


ave_tf=mean(iostropic_tf(:,250:265),2);
[~,m0]=max(ave_tf);
for i=1:size(tf,2)
    [cc,lag]=xcorr(ave_tf,iostropic_tf(:,i));
    [~,temp_flag]=max(cc);
    temp_ref_pf_evolution(i,1)=m0-lag(temp_flag);
end
I=temp_ref_pf_evolution>1.7*m0|temp_ref_pf_evolution<0.3*m0;
temp_ref_pf_evolution(I)=nan;
temp_ref_pf_evolution=smooth(temp_ref_pf_evolution,0.2,'rloess');
temp_ref_pf_evolution(1:30)=temp_ref_pf_evolution(31);
%-----------------------------------------------------------------
% Determin the preliminary travel time evolution based on the 
% cross-correlation result.
for i=1:size(tf,3)
    for j=1:size(tf,2)
        [~,temp_m]=findpeaks(tf(:,j,i));
        [~,flag]=min(abs(temp_m-temp_ref_pf_evolution(j,1)));
        if temp_m(flag)>1.2*temp_ref_pf_evolution(j,1)|temp_m(flag)<0.8*temp_ref_pf_evolution(j,1)
            pf(j,i)=nan;
        else
            pf(j,i)=temp_m(flag);
        end
    end
end
Ref_pf_evolution=smooth(mean(pf,2,'omitnan'),0.2,'rloess');
Ref_pf_evolution(1:30)=Ref_pf_evolution(31);
end

